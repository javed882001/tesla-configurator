chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.command === "getUsedCSS") {
    console.log('COMMAND');
    chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
      const activeTab = tabs[0];

      chrome.debugger.attach({ tabId: activeTab.id }, "1.2", function () {
        chrome.debugger.sendCommand({ tabId: activeTab.id }, "DOM.enable", function () {
          console.log('DOM ON');
        });
        chrome.debugger.sendCommand({ tabId: activeTab.id }, "Page.enable", function () {
          console.log('Page ON');
        });
        chrome.debugger.sendCommand({ tabId: activeTab.id }, "CSS.enable", function () {
          console.log('CSS ON');
          chrome.debugger.sendCommand({ tabId: activeTab.id }, "CSS.startRuleUsageTracking", undefined, function () {
            console.log('CSS Tracking ON');
            chrome.debugger.sendCommand({ tabId: activeTab.id }, "CSS.takeCoverageDelta", undefined, function (result) {
              console.log('CSS Tracking Coverage');
              const optimized = [];
              const downloadFile = function (data, filename) {
                if (window.injected === undefined || window.injected !== true) {
                  window.injected = true;

                  let element = document.createElement('a');

                  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(data));
                  element.setAttribute('download', filename);
                  element.style.display = 'none';
                  document.body.appendChild(element);
                  element.click();
                  document.body.removeChild(element);
                } else {
                  console.log('already downloaded');
                }
              };

              result.coverage.forEach(element => { // fills in the background (async)
                if (element.used) {
                  chrome.debugger.sendCommand({ tabId: activeTab.id }, "CSS.getStyleSheetText", { styleSheetId: element.styleSheetId }, function (css) {
                    optimized.push(css.text.slice(element.startOffset, element.endOffset));
                  });
                }
              });
              chrome.debugger.sendCommand({ tabId: activeTab.id }, "CSS.stopRuleUsageTracking", undefined, function () {
                console.log('CSS Tracking OFF');
              });
              setTimeout(() => { // waiting for fill
                chrome.debugger.detach({ tabId: activeTab.id });
                chrome.scripting.executeScript({
                  target: { tabId: activeTab.id, allFrames: false },
                  func: downloadFile,
                  args: [optimized.join(''), 'optimized.css']
                });
              }, 5000);
            });
          });
        });
      });
    });
  }
});