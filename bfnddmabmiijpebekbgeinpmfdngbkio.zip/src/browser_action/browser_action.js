document.getElementById("getUsedCSS").addEventListener("click", function(el) {
    el.target.textContent = 'Downloading...';

    chrome.runtime.sendMessage({
        command: "getUsedCSS"
    });

    setTimeout(() => {
        el.target.textContent = 'Download';
    }, 8000);
});